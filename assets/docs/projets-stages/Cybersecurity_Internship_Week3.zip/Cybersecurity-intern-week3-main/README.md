# 🔐 Penetration Testing & Password Auditing Lab

## Networkwalks — Week 03

> **PDF Password Auditing • John the Ripper • Johnny • Networkwalks Tools • Claude Code • HexStrike AI • MCP Integration**

![Kali Linux](https://img.shields.io/badge/OS-Kali%20Linux-557C94?logo=kalilinux&logoColor=white)
![Networkwalks](https://img.shields.io/badge/Lab-Networkwalks-00A86B)
![Cybersecurity](https://img.shields.io/badge/Focus-Cybersecurity-red)
![Status](https://img.shields.io/badge/Status-Completed-success)

---

## 👤 About This Project

This repository documents my practical experience during **Week 03 of the Networkwalks Cybersecurity Program**.

The objective of this week was to move from reconnaissance activities into practical **password auditing and security-tool automation**. The exercises focused on extracting password-verification data from protected PDF files, performing controlled dictionary-based password auditing with **John the Ripper (JTR)** and **Johnny**, using Networkwalks' training tools, and integrating **Claude Code / Claude Desktop** with **HexStrike AI** through MCP.

All activities documented here were performed in the **Networkwalks training / CTF environment** and against files or systems used for authorized learning.

---

# ⚠️ Ethical & Legal Disclaimer

This repository is intended for **cybersecurity education, authorized security testing, and defensive research only**.

The password-auditing exercises documented here were performed against **training PDFs provided for the Networkwalks exercises**.

No unauthorized access, credential theft, destructive activity, or testing of third-party systems was performed.

> **Only audit passwords, files, systems, and networks that you own or have explicit permission to test.**

---

# 🎯 Project Scope

| Phase | Activity |
|---|---|
| Phase 1 | PDF Security & Hash Extraction |
| Phase 2 | Password Auditing with JTR / Johnny |
| Phase 3 | Networkwalks Password-Cracking Exercises |
| Phase 4 | Claude Code / Claude Desktop Integration |
| Phase 5 | HexStrike AI API & MCP Integration |
| Phase 6 | Validation, Flag Capture & Documentation |

### Main Training Environment

```text
Networkwalks Cybersecurity Training / CTF
```

### HexStrike API

```text
http://127.0.0.1:8888
```

---

# 🛠️ Tools Used

| Tool | Purpose |
|---|---|
| **Kali Linux** | Cybersecurity laboratory environment |
| **pdf2john** | Extract PDF password-verification data for John the Ripper |
| **John the Ripper (JTR)** | Controlled dictionary-based password auditing |
| **Johnny** | Graphical interface for John the Ripper |
| **Networkwalks Hash Calculator** | Training exercise for PDF hash extraction |
| **Networkwalks Password Cracker** | Training exercise for dictionary-based password auditing |
| **Claude Code / Claude Desktop** | AI-assisted security workflow |
| **HexStrike AI** | Local security-tool automation/API layer |
| **HexStrike MCP** | MCP bridge between Claude and HexStrike |
| **cURL** | Local HexStrike API health/status verification |
| **rockyou.txt** | Dictionary used in the controlled training exercise |

---

# 1. 🔐 PDF Hash Extraction

The first part of Week 03 focused on understanding how password-protected PDF files can contain password-verification data that can be audited offline.

The Networkwalks hash-calculator exercise demonstrated the extraction of a **`$pdf$...`** hash compatible with password-auditing tools.

### Workflow

```text
Protected PDF
     │
     ▼
PDF Hash Extraction
     │
     ▼
$pdf$... Hash
     │
     ▼
John the Ripper / Johnny
     │
     ▼
Password Verification
```

### Local extraction

For an authorized local training file:

```bash
pdf2john protected.pdf > pdf_hash.txt
```

The resulting file contains a line beginning with:

```text
$pdf$
```

This is not the PDF password itself. It is password-verification data used by the auditing tool.

### Evidence

![Networkwalks PDF hash calculator](evidences/hashcalc1.png)

![PDF hash output](evidences/pdf1.png)

![PDF hash exercise](evidences/pdf2.png)

![PDF exercise result](evidences/pdf3.png)

---

# 2. 🔑 John the Ripper (JTR)

## 2.1 Preparing the hash

The extracted PDF hash was saved into a text file for John the Ripper.

```bash
pdf2john protected.pdf > pdf_hash.txt
```

The resulting file can then be supplied to John for a controlled password-auditing exercise.

---

## 2.2 Dictionary-Based Password Audit

The training exercise used a dictionary-based approach.

Example:

```bash
john --wordlist=/usr/share/wordlists/rockyou.txt pdf_hash.txt
```

To display a password already recovered by John:

```bash
john --show pdf_hash.txt
```

The important concept is that John does not "decrypt" the hash. Instead, it tests candidate passwords and checks whether they satisfy the password-verification data contained in the hash.

---

# 3. 🖥️ Johnny — John the Ripper GUI

**Johnny** was used to manage the John the Ripper password-auditing exercise through a graphical interface.

The supplied screenshots show successful recovery of passwords from the **Networkwalks training PDFs**.

### Recovered training passwords

```text
good-luck
password1
1qaz2wsX
```

These values belong to the training exercises shown in the supplied evidence.

### Johnny Evidence

![Johnny — first recovery](evidences/johnnycrck1.png)

![Johnny — second recovery](evidences/johnnycrck2.png)

![Johnny — third recovery](evidences/johnnycrck3.png)

The exercise also demonstrated that John can recognize hashes that have already been processed and retrieve the recovered result from its existing password cache / pot file.

---

# 4. 🌐 Networkwalks Password Cracker

Networkwalks provided browser-based password-auditing exercises demonstrating dictionary attacks against PDF password hashes.

The screenshots show candidate passwords being tested until a matching password was found.

## Example 1

```text
good-luck
```

![Networkwalks password cracker — example 1](evidences/passcrack1.png)

## Example 2

```text
password1
```

![Networkwalks password cracker — example 2](evidences/passcrack2.png)

## Example 3

```text
1qaz2wsX
```

![Networkwalks password cracker — example 3](evidences/passcrack3.png)

### Security Lesson

The exercises demonstrated why common passwords are vulnerable to dictionary attacks.

For example:

```text
password1
```

is much weaker than a long, unique passphrase.

---

# 5. 🌐 Networkwalks Online Hash Exercise

The online hash-conversion exercise demonstrated another method of extracting PDF password-verification data suitable for John the Ripper / Hashcat-compatible workflows.

![Online PDF hash extraction](evidences/onlinehashcrack.png)

### Security Note

For real confidential documents, local tools should be preferred over third-party upload services.

For example:

```bash
pdf2john protected.pdf > pdf_hash.txt
```

keeps the original document on the local system.

---

# 6. 🤖 Claude Code / Claude Desktop

A major objective of Week 03 was learning how an AI client can interact with locally available cybersecurity tooling.

The practical architecture was:

```text
┌─────────────────────┐
│ Claude Desktop      │
│ / Claude Code       │
└──────────┬──────────┘
           │ MCP
           ▼
┌─────────────────────┐
│ hexstrike_mcp.py    │
│ MCP Client          │
└──────────┬──────────┘
           │ HTTP
           │ 127.0.0.1:8888
           ▼
┌─────────────────────┐
│ hexstrike_server.py │
│ Tools API Server    │
└──────────┬──────────┘
           │
           ▼
┌─────────────────────────────────┐
│ Local security tools             │
│ JTR / nmap / nikto / sqlmap /   │
│ ffuf / gobuster / aircrack-ng / │
│ etc.                             │
└─────────────────────────────────┘
```

This showed the distinction between:

```text
Claude
  ↓
MCP
  ↓
HexStrike
  ↓
Local Security Tools
```

---

# 7. ⚙️ Starting the HexStrike AI API Server

The HexStrike API server was started from the project directory.

```bash
cd ~/hexstrike-ai/hexstrike-ai
source venv/bin/activate
python hexstrike_server.py --port 8888
```

The server displayed:

```text
Starting HexStrike AI Tools API Server
Port: 8888
Debug Mode: False
Cache Size: 1000
Command Timeout: 300s
Enhanced Visual Engine: Active
```

![HexStrike API server](evidences/hexstrike_server.png)

---

# 8. 🔌 Starting the HexStrike MCP Client

A second terminal was used to start the MCP client.

```bash
cd ~/hexstrike-ai/hexstrike-ai
source venv/bin/activate

python hexstrike_mcp.py --server http://127.0.0.1:8888
```

The client successfully connected to:

```text
http://127.0.0.1:8888
```

The terminal reported:

```text
Successfully connected to HexStrike AI API Server
Server health status: healthy
Server version: 6.0.0
Ready to serve AI agents with enhanced cybersecurity capabilities.
```

![HexStrike MCP connection](evidences/hexstrike_mcp.png)

---

# 9. 🩺 HexStrike API Health Check

The local API was verified with:

```bash
curl http://127.0.0.1:8888/health
```

The server returned:

```json
{
  "status": "healthy",
  "message": "HexStrike AI Tools API Server is operational",
  "version": "6.0.0"
}
```

The environment reported:

```text
Essential tools available: 8 / 8
Total tools available:     79 / 127
Server version:             6.0.0
Status:                     healthy
```

The health response also reported telemetry and category-level tool availability.

### Example available tools

```text
aircrack-ng
amass
arp-scan
burpsuite
curl
dirb
dirsearch
enum4linux
ffuf
gobuster
hashcat
hydra
john
masscan
nikto
nmap
nuclei
responder
searchsploit
sqlmap
subfinder
tcpdump
wireshark
wpscan
...
```

> Tool availability depends on the local Kali installation and the HexStrike configuration.

![HexStrike interface](evidences/hexstrike.png)

---

# 10. 🧩 Claude Desktop MCP Configuration

The Claude Desktop configuration used an MCP server entry for HexStrike.

The configuration file was:

```text
~/.config/Claude/claude_desktop_config.json
```

The important point is that the configuration must reference the **real local path** to `hexstrike_mcp.py`, rather than the placeholder `/path/to/...`.

Example:

```json
{
  "mcpServers": {
    "hexstrike-ai": {
      "command": "python3",
      "args": [
        "/home/msm/hexstrike-ai/hexstrike-ai/hexstrike_mcp.py",
        "--server",
        "http://127.0.0.1:8888"
      ],
      "description": "HexStrike AI v6.0 - Advanced Cybersecurity Automation Platform",
      "timeout": 300,
      "disabled": false
    }
  }
}
```

After modifying the configuration, Claude Desktop must be restarted so that the MCP integration can be loaded again.

---

# 11. ✅ Claude + HexStrike Verification

Claude successfully recognized the HexStrike integration.

The Claude interface reported:

```text
Loaded tools, used hexstrike-ai integration
```

and showed:

```text
Status: healthy
Version: 6.0.0
Essential tools: 8/8
Available tools: 79/127
```

![Claude + HexStrike](evidences/claude.png)

This confirmed that the integration was not only present in the JSON configuration: Claude was able to communicate with the running HexStrike service.

---

# 12. 🔄 Claude-Assisted JTR Workflow

The complete Week 03 workflow can be represented as:

```text
Identify Training PDF
        │
        ▼
Extract PDF Hash
        │
        ▼
Create JTR Hash File
        │
        ▼
Run Controlled Dictionary Audit
        │
        ▼
Check John / Johnny Result
        │
        ▼
Validate Training PDF
        │
        ▼
Capture Networkwalks Flag
        │
        ▼
Document Results
```

Claude and HexStrike were then used as an AI-assisted layer around the local security-tool environment.

![Claude + JTR workflow](evidences/jtr_claude.png)

---

# 13. 🏆 Flags Captured

The supplied Week 03 screenshots document three Networkwalks training achievements.

## Flag 1

```text
nw{cybersecurity_flag_captured_2608}
```

![Flag 1](evidences/claude.png)

## Flag 2

```text
nw{networkwalks_persistence_jtr_270521}
```

![Flag 2](evidences/pdf2.png)

## Flag 3

```text
nw{networkwalks_flag_260821_1}
```

![Flag 3](evidences/pdf3.png)

These flags are recorded as **training / CTF achievements demonstrated in the supplied screenshots**.

---

# 14. 📊 Consolidated Findings

| # | Observation | Tool | Significance | Risk |
|---|---|---|---|---|
| 1 | Protected PDFs produced `$pdf$...` verification data | pdf2john / Networkwalks | Enables controlled offline password auditing | Medium |
| 2 | Common passwords were recovered through dictionary testing | JTR / Johnny | Demonstrates weakness of predictable passwords | Medium |
| 3 | Previously processed hashes could be recovered from John's cache/pot file | JTR | Shows persistence of local cracking results | Low |
| 4 | Networkwalks provided successful training password-auditing exercises | Networkwalks Tools | Reinforced dictionary-attack concepts | Medium |
| 5 | HexStrike API was reachable locally | cURL | Confirms backend availability | Low |
| 6 | 79 of 127 configured tools were available | HexStrike | Demonstrates broad local tool integration | Medium |
| 7 | All 8 essential tools were available | HexStrike | Confirms core tool availability | Low |
| 8 | Claude successfully connected through MCP | Claude + HexStrike | Demonstrates AI-to-local-tool integration | Medium |

> These observations describe the authorized training environment. They are not claims of vulnerabilities in unrelated systems.

---

# 15. 🧠 Risk Analysis

Week 03 demonstrated two important security concepts.

### Password Security

```text
Weak / Predictable Password
            ↓
Dictionary
            ↓
Candidate Testing
            ↓
Password Recovered
```

This demonstrates why passwords such as:

```text
password1
```

should not be used for sensitive accounts or protected documents.

### AI-Assisted Security Tooling

```text
AI Client
   ↓
MCP
   ↓
Automation Layer
   ↓
Security Tools
   ↓
Results
   ↓
AI Analysis
```

The integration can reduce the friction between an analyst and multiple local security tools, but it also makes authorization and scope controls particularly important.

---

# 16. 🛡️ Recommendations

1. **Use strong, unique passwords**  
   Avoid common words, predictable patterns, and passwords appearing in common dictionaries.

2. **Prefer long passphrases**  
   Length and uniqueness significantly improve resistance to dictionary attacks.

3. **Protect confidential PDFs**  
   Use strong passwords when encrypting sensitive PDF documents.

4. **Perform password auditing only with authorization**  
   Offline auditing should be limited to files and accounts that you are authorized to assess.

5. **Prefer local processing for sensitive files**  
   Avoid uploading confidential documents to third-party hash-conversion or password-auditing websites.

6. **Secure AI-to-tool integrations**  
   MCP clients and automation servers should be restricted to authorized users and controlled environments.

7. **Bind security services carefully**  
   Keep development APIs such as the HexStrike server restricted to the local host unless remote access is explicitly required and secured.

8. **Monitor installed security tooling**  
   Know which tools are exposed through an MCP/automation layer and what permissions they have.

9. **Separate training from production environments**  
   Use dedicated lab machines, virtual machines, or controlled test environments for security experimentation.

10. **Document authorization and scope**  
    Every security assessment should have a clearly defined target, scope, and permission boundary.

---

# 17. 📚 What I Learned

## John the Ripper

- How PDF password-verification data can be extracted for offline auditing.
- How the `$pdf$...` format is used by JTR-compatible workflows.
- How dictionary attacks work.
- How John stores recovered passwords in its pot file.
- How `john --show` can retrieve a previously recovered result.

## PDF Security

- A protected PDF is not automatically protected by a strong password.
- Predictable passwords can be recovered through dictionary-based auditing.
- Strong and unique passwords provide substantially better resistance.

## Johnny

- How to load and manage a JTR password-auditing session graphically.
- How to inspect recovered credentials.
- How existing cracking results can be recognized and reused.

## Networkwalks Tools

- How web-based training tools demonstrate hash extraction and dictionary attacks.
- Why password complexity matters.
- Why password auditing should be performed only in an authorized environment.

## Claude + MCP

- An MCP server can expose local capabilities to an AI client.
- The MCP client and the backend API are separate components.
- A healthy backend API does not automatically prove that Claude has loaded the MCP integration.
- Both the API layer and the Claude/MCP layer need to be verified.

## HexStrike AI

- How a local API server can act as an automation layer for multiple security tools.
- How an MCP client can connect an AI application to that API.
- How tool availability depends on the local Kali installation and configuration.
- Why access controls are important when exposing powerful security tools through automation.

---

# 18. 🔧 Troubleshooting Checklist

### Check HexStrike API

```bash
curl http://127.0.0.1:8888/health
```

Expected:

```text
"status":"healthy"
```

### Check the listening port

```bash
ss -lntp | grep 8888
```

### Start HexStrike API

```bash
cd ~/hexstrike-ai/hexstrike-ai
source venv/bin/activate
python hexstrike_server.py --port 8888
```

### Start HexStrike MCP

```bash
cd ~/hexstrike-ai/hexstrike-ai
source venv/bin/activate
python hexstrike_mcp.py --server http://127.0.0.1:8888
```

### Verify Python

```bash
which python3
python3 --version
```

Inside the virtual environment:

```bash
which python
python --version
```

### Verify John

```bash
john --version
```

### Locate pdf2john

```bash
which pdf2john
```

If it is not in `PATH`:

```bash
find /usr/share -name 'pdf2john*' 2>/dev/null
```

---

# 19. 💻 Key Commands Summary

```bash
# Activate HexStrike environment
cd ~/hexstrike-ai/hexstrike-ai
source venv/bin/activate

# Start HexStrike API
python hexstrike_server.py --port 8888

# Start HexStrike MCP
python hexstrike_mcp.py --server http://127.0.0.1:8888

# Check HexStrike health
curl http://127.0.0.1:8888/health

# Extract a PDF hash locally
pdf2john protected.pdf > pdf_hash.txt

# Controlled dictionary audit
john --wordlist=/usr/share/wordlists/rockyou.txt pdf_hash.txt

# Display recovered result
john --show pdf_hash.txt

# Check HexStrike listening port
ss -lntp | grep 8888
```

---

# 20. 🧪 Ethical / Lab Scope

All password-auditing activities documented in this report were performed as part of the **Networkwalks cybersecurity training / CTF environment** represented by the supplied evidence.

The same techniques should only be applied to:

- files you own,
- systems you are authorized to test,
- or explicitly provided training / CTF targets.

For real confidential PDFs, prefer local processing rather than uploading documents or password hashes to third-party online services.

---

# 21. 📸 Evidence

The practical evidence includes:

- Networkwalks PDF hash extraction
- PDF hash outputs
- Johnny password-auditing sessions
- Networkwalks password-cracker exercises
- Online hash-conversion exercise
- HexStrike API server
- HexStrike MCP connection
- HexStrike health/API status
- Claude + HexStrike integration
- Claude-assisted JTR workflow
- Networkwalks training flags

Screenshots are stored in the `screenshots/` directory.

---

# 22. 🏁 Conclusion

Week 03 provided a practical transition from reconnaissance into **password auditing and AI-assisted security automation**.

The complete progression was:

```text
PDF Security
      ↓
Hash Extraction
      ↓
John the Ripper
      ↓
Johnny GUI
      ↓
Dictionary Auditing
      ↓
Networkwalks Training Tools
      ↓
Claude / Claude Code
      ↓
HexStrike API
      ↓
HexStrike MCP
      ↓
AI-Assisted Local Security Workflow
```

The most important lesson was that technical capability must always be combined with **authorization, scope control, and responsible handling of sensitive information**.

This week strengthened my practical skills in:

- **PDF security**
- **Password auditing**
- **John the Ripper**
- **Johnny**
- **Dictionary attacks**
- **Security-tool automation**
- **MCP architecture**
- **Claude + local tool integration**
- **Cybersecurity documentation**
- **Responsible security testing**

> **Learn → Practice → Verify → Document → Improve**

---

## 👤 Author

**Mohamed Salem Abdel Wedoud**

Cybersecurity Professional — B082

**Program:** Networkwalks Cybersecurity Program  
**Week:** 03  
**Focus:** PDF Password Auditing, JTR, Claude Code & HexStrike AI

---

## ⭐ Project Workflow

```text
Protected PDF
      ↓
Hash Extraction
      ↓
JTR / Johnny
      ↓
Password Auditing
      ↓
Networkwalks CTF
      ↓
Claude / Claude Code
      ↓
MCP
      ↓
HexStrike AI
      ↓
Local Security Tools
      ↓
Validation
      ↓
Documentation
```

**Learn → Practice → Analyze → Document → Improve**
